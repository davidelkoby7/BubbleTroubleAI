"""
Module for handling the core game mechanics.
"""