"""
Module for all the core base objects.
"""