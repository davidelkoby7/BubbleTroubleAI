"""
Module for the basic utils (constants, types, general utils, etc).
"""