
class CantLoadBotException(Exception):
    pass
